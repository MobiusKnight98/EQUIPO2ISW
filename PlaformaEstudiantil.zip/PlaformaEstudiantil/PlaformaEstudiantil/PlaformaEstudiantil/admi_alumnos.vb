﻿Public Class admi_alumnos
    Private Sub admi_alumnos_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class