﻿Public Class admi_maestros
    Private Sub admi_maestros_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class