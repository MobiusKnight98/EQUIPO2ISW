﻿Public Class menu_admi
    Private Sub menu_admi_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) 

    End Sub
End Class