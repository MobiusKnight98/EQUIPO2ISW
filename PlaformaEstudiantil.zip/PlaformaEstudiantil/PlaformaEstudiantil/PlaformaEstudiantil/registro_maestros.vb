﻿Public Class registro_maestros
    Private Sub registro_maestros_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class